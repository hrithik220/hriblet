# 🧠 Hriblet — AI Capsule Memory Extension

> **"Never Explain Your Project Twice."**

Hriblet is a Chrome Extension that gives AI assistants a persistent memory through a **Capsule system**. Save your project context once, inject it into any AI chat in one click.

---

## ✨ Features

| Feature | Description |
|---|---|
| **Capsule System** | Save project stack, goal, modules, APIs & notes |
| **One-Click Inject** | Inject full context into Claude, ChatGPT, or Gemini |
| **Multi-Project** | Switch between unlimited projects instantly |
| **Injection History** | Track what was injected where and when |
| **Export / Import** | Backup capsules as JSON, restore anytime |
| **Auto Platform Detection** | Detects which AI page you're on automatically |

---

## 🚀 Installation (Developer Mode)

1. Download or clone this folder
2. Open Chrome → `chrome://extensions/`
3. Enable **Developer Mode** (top right toggle)
4. Click **"Load unpacked"**
5. Select the `hriblet/` folder
6. The Hriblet icon appears in your toolbar ✅

---

## 📁 File Structure

```
hriblet/
├── manifest.json          # Chrome Extension Manifest v3
├── popup.html             # Main popup UI
├── popup.css              # All styles
├── popup.js               # UI logic & state management
├── icons/
│   ├── icon16.png
│   ├── icon32.png
│   ├── icon48.png
│   └── icon128.png
└── src/
    ├── background.js      # Service worker (messaging, storage init)
    ├── content.js         # Page-level injection into AI chat inputs
    └── storage.js         # chrome.storage.local helpers
```

---

## 🔧 How It Works

### Capsule Format
Each capsule stores:
- **Name** — e.g. "Campus Share v2"
- **Project** — group name for tab switching
- **Stack** — tech tags (React, Node.js, etc.)
- **Goal** — one-line project description
- **Modules** — feature list
- **APIs** — endpoints / external services
- **Notes** — current status, blockers, reminders

### Injection
When you click **Inject**, Hriblet:
1. Formats the capsule as a structured text block
2. Sends it to the content script via `chrome.runtime.sendMessage`
3. Content script locates the AI chat input (textarea or ProseMirror)
4. Prepends the context block using `document.execCommand('insertText')`
5. Fires `input` & `change` events so React/Vue picks up the change

---

## 🌐 Supported Platforms

- **Claude** (`claude.ai`) — ProseMirror editor
- **ChatGPT** (`chatgpt.com`) — textarea / contenteditable
- **Gemini** (`gemini.google.com`) — Quill editor

---

## 🛠 Tech Stack

- JavaScript (ES2022, no build step)
- Chrome Extension Manifest v3
- `chrome.storage.local` for persistence
- DOM injection via `execCommand` + input events
- Pure CSS (no framework)

---

## 🗺 Roadmap

- [ ] Cloud sync via Firebase
- [ ] Capsule templates library
- [ ] AI-assisted capsule generation
- [ ] Perplexity & Mistral support
- [ ] Team sharing / collaboration

---

## 📄 License

MIT — built by Hriblet team.

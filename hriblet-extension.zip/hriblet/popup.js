// ═══════════════════════════════════════════════════════
// Hriblet — popup.js
// Full UI controller for the Chrome Extension popup
// ═══════════════════════════════════════════════════════

'use strict';

// ── State ────────────────────────────────────────────
let state = {
  capsules: [],
  activeCapsuleId: null,
  activeProject: null,
  platform: 'unknown',
  editColor: '#a29bfe',
  history: []
};

// ── DOM refs ─────────────────────────────────────────
const $ = id => document.getElementById(id);
const $$ = sel => document.querySelectorAll(sel);

// ── Init ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  await loadState();
  detectPlatform();
  renderAll();
  bindEvents();
});

async function loadState() {
  const data = await HribletStorage.get([
    'capsules', 'activeCapsuleId', 'activeProject', 'settings', 'injectHistory'
  ]);
  state.capsules = data.capsules || [];
  state.activeCapsuleId = data.activeCapsuleId || (state.capsules[0]?.id ?? null);
  state.activeProject = data.activeProject || (state.capsules[0]?.project ?? null);
  state.settings = data.settings || { autoDetect: true, showBadge: true, cloudSync: false };
  state.history = data.injectHistory || [];
}

function detectPlatform() {
  chrome.runtime.sendMessage({ type: 'GET_PLATFORM' }, (res) => {
    if (res) {
      state.platform = res.platform;
      updatePlatformUI(res.platform);
    }
  });
}

function updatePlatformUI(platform) {
  const dot = $('platform-dot');
  const label = $('platform-label');
  const names = { claude: 'Claude', chatgpt: 'ChatGPT', gemini: 'Gemini', unknown: 'No AI page' };
  label.textContent = names[platform] || 'Unknown';
  if (platform !== 'unknown') {
    dot.classList.add('active');
  } else {
    dot.classList.remove('active');
    label.textContent = 'Open an AI page';
  }
}

// ── Render ───────────────────────────────────────────
function renderAll() {
  renderProjectTabs();
  renderActiveCapsule();
  renderOtherCapsules();
  renderHistory();
  renderSettings();
}

function renderProjectTabs() {
  const projects = [...new Set(state.capsules.map(c => c.project))];
  const container = $('project-tabs');
  container.innerHTML = '';

  projects.forEach(proj => {
    const btn = document.createElement('button');
    btn.className = 'proj-tab' + (proj === state.activeProject ? ' active' : '');
    btn.textContent = proj;
    btn.onclick = () => switchProject(proj);
    container.appendChild(btn);
  });
}

function switchProject(proj) {
  state.activeProject = proj;
  const caps = state.capsules.filter(c => c.project === proj);
  if (caps.length) {
    state.activeCapsuleId = caps[0].id;
    HribletStorage.set({ activeProject: proj, activeCapsuleId: caps[0].id });
  }
  renderAll();
}

function renderActiveCapsule() {
  const cap = getActiveCapsule();
  if (!cap) {
    $('active-capsule-card').style.display = 'none';
    return;
  }
  $('active-capsule-card').style.display = '';
  $('active-cap-name').textContent = cap.name;

  // Reset inject button
  const injectBtn = $('btn-inject');
  injectBtn.className = 'inject-btn';
  injectBtn.innerHTML = `
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
    Inject
  `;

  // Render fields
  const fields = $('capsule-fields');
  fields.innerHTML = `
    <div class="cap-field">
      <span class="cap-key">Stack</span>
      <span class="cap-val tag-list">
        ${(cap.stack || []).map(s => `<span class="tag tech">${s}</span>`).join('')}
      </span>
    </div>
    <div class="cap-field">
      <span class="cap-key">Goal</span>
      <span class="cap-val">${esc(cap.goal)}</span>
    </div>
    <div class="cap-field">
      <span class="cap-key">Modules</span>
      <span class="cap-val tag-list">
        ${(cap.modules || []).map(m => `<span class="tag module">${m}</span>`).join('')}
      </span>
    </div>
    ${cap.apis ? `
    <div class="cap-field">
      <span class="cap-key">APIs</span>
      <span class="cap-val cap-mono">${esc(cap.apis)}</span>
    </div>` : ''}
    <div class="cap-field" style="flex-direction:column; gap:4px">
      <div class="notes-box">
        <div class="notes-label">Notes</div>
        <div class="notes-text">${esc(cap.notes)}</div>
      </div>
    </div>
  `;

  // Accent border
  $('active-capsule-card').style.borderColor = cap.color
    ? cap.color + '44'
    : 'rgba(124,111,224,0.25)';
}

function renderOtherCapsules() {
  const list = $('other-capsules-list');
  list.innerHTML = '';

  const others = state.capsules.filter(c => c.id !== state.activeCapsuleId);
  if (others.length === 0) {
    $('other-capsules-section').style.display = 'none';
    return;
  }
  $('other-capsules-section').style.display = '';

  others.forEach(cap => {
    const el = document.createElement('div');
    el.className = 'mini-capsule';
    el.innerHTML = `
      <div class="mini-left">
        <div class="mini-dot" style="background:${cap.color || '#a29bfe'}"></div>
        <div>
          <div class="mini-name">${esc(cap.name)}</div>
          <div class="mini-meta">${cap.project} · ${HribletStorage.timeAgo(cap.updatedAt)}</div>
        </div>
      </div>
      <span class="mini-badge">${(cap.stack || []).slice(0, 2).join(' · ')}</span>
    `;
    el.onclick = () => {
      state.activeCapsuleId = cap.id;
      state.activeProject = cap.project;
      HribletStorage.set({ activeCapsuleId: cap.id, activeProject: cap.project });
      renderAll();
    };
    list.appendChild(el);
  });
}

function renderHistory() {
  const list = $('history-list');
  const empty = $('history-empty');
  list.innerHTML = '';

  if (state.history.length === 0) {
    empty.style.display = 'flex';
    return;
  }
  empty.style.display = 'none';

  [...state.history].reverse().forEach(item => {
    const el = document.createElement('div');
    el.className = 'history-item';
    el.innerHTML = `
      <div class="history-icon">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M13 2L3 14h9l-1 8 10-12h-9l1-8z"/></svg>
      </div>
      <div class="history-info">
        <div class="history-name">${esc(item.capsuleName)}</div>
        <div class="history-meta">${esc(item.platform)} · ${HribletStorage.timeAgo(item.ts)}</div>
      </div>
    `;
    list.appendChild(el);
  });
}

function renderSettings() {
  $('set-autodetect').checked = state.settings?.autoDetect ?? true;
  $('set-badge').checked = state.settings?.showBadge ?? true;
  $('set-cloud').checked = state.settings?.cloudSync ?? false;
}

// ── Events ───────────────────────────────────────────
function bindEvents() {

  // Nav tabs
  $$('.nav-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const screen = btn.dataset.screen;
      switchScreen(screen);
      $$('.nav-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // Settings icon → settings screen
  $('btn-settings').addEventListener('click', () => {
    switchScreen('settings');
    $$('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-screen="settings"]').classList.add('active');
  });

  // Inject
  $('btn-inject').addEventListener('click', handleInject);

  // Edit active capsule
  $('btn-edit-active').addEventListener('click', () => {
    const cap = getActiveCapsule();
    if (cap) openEditor(cap);
  });

  // Copy active capsule context
  $('btn-copy-active').addEventListener('click', () => {
    const cap = getActiveCapsule();
    if (!cap) return;
    const text = formatCapsuleText(cap);
    navigator.clipboard.writeText(text).then(() => {
      showToast('✓ Copied to clipboard', 'success');
    });
  });

  // Delete active capsule
  $('btn-delete-active').addEventListener('click', async () => {
    const cap = getActiveCapsule();
    if (!cap) return;
    if (!confirm(`Delete "${cap.name}"?`)) return;
    await HribletStorage.deleteCapsule(cap.id);
    state.capsules = state.capsules.filter(c => c.id !== cap.id);
    state.activeCapsuleId = state.capsules[0]?.id || null;
    state.activeProject = state.capsules[0]?.project || null;
    renderAll();
    showToast('Capsule deleted', 'info');
  });

  // New capsule
  $('btn-new-capsule').addEventListener('click', () => openEditor(null));

  // Editor back
  $('btn-back-editor').addEventListener('click', () => {
    switchScreen('capsules');
    $$('.nav-btn').forEach(b => b.classList.remove('active'));
    document.querySelector('[data-screen="capsules"]').classList.add('active');
  });

  // Save capsule
  $('btn-save-capsule').addEventListener('click', handleSaveCapsule);

  // Color swatches
  $$('.swatch').forEach(sw => {
    sw.addEventListener('click', () => {
      $$('.swatch').forEach(s => s.classList.remove('active'));
      sw.classList.add('active');
      state.editColor = sw.dataset.color;
    });
  });

  // Settings toggles
  $('set-autodetect').addEventListener('change', saveSettings);
  $('set-badge').addEventListener('change', saveSettings);
  $('set-cloud').addEventListener('change', saveSettings);

  // Export
  $('btn-export').addEventListener('click', handleExport);

  // Import
  $('btn-import').addEventListener('click', () => $('import-file').click());
  $('import-file').addEventListener('change', handleImport);
}

// ── Screen routing ───────────────────────────────────
function switchScreen(name) {
  const screens = {
    capsules: 'screen-capsules',
    history: 'screen-history',
    settings: 'screen-settings',
    editor: 'screen-editor'
  };
  Object.values(screens).forEach(id => {
    const el = $(id);
    if (el) el.classList.add('hidden');
  });
  const target = screens[name];
  if (target) $(target)?.classList.remove('hidden');
}

// ── Inject handler ───────────────────────────────────
function handleInject() {
  const cap = getActiveCapsule();
  if (!cap) return;

  if (state.platform === 'unknown') {
    showToast('⚠ Open ChatGPT, Claude or Gemini first', 'error');
    return;
  }

  chrome.runtime.sendMessage(
    { type: 'INJECT_CAPSULE', capsule: cap, platform: state.platform },
    (res) => {
      if (res?.success) {
        const btn = $('btn-inject');
        btn.classList.add('injected');
        btn.innerHTML = `
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" width="13" height="13"><polyline points="20 6 9 17 4 12"/></svg>
          Injected
        `;
        showToast(`✓ Context injected into ${platformName()}`, 'success');

        // Log to history
        const entry = { capsuleName: cap.name, platform: platformName(), ts: Date.now() };
        state.history.push(entry);
        if (state.history.length > 50) state.history = state.history.slice(-50);
        HribletStorage.set({ injectHistory: state.history });
      } else {
        showToast('⚠ ' + (res?.error || 'Injection failed'), 'error');
      }
    }
  );
}

// ── Editor ───────────────────────────────────────────
function openEditor(cap) {
  $('editor-title').textContent = cap ? 'Edit Capsule' : 'New Capsule';
  $('edit-id').value = cap?.id || '';
  $('edit-name').value = cap?.name || '';
  $('edit-project').value = cap?.project || '';
  $('edit-stack').value = (cap?.stack || []).join(', ');
  $('edit-goal').value = cap?.goal || '';
  $('edit-modules').value = (cap?.modules || []).join(', ');
  $('edit-apis').value = cap?.apis || '';
  $('edit-notes').value = cap?.notes || '';

  // Set color swatch
  const color = cap?.color || '#a29bfe';
  state.editColor = color;
  $$('.swatch').forEach(sw => {
    sw.classList.toggle('active', sw.dataset.color === color);
  });

  switchScreen('editor');
}

async function handleSaveCapsule() {
  const name = $('edit-name').value.trim();
  const project = $('edit-project').value.trim();
  if (!name || !project) {
    showToast('Name and Project are required', 'error');
    return;
  }

  const capsule = {
    id: $('edit-id').value || HribletStorage.generateId(),
    name,
    project,
    stack: $('edit-stack').value.split(',').map(s => s.trim()).filter(Boolean),
    goal: $('edit-goal').value.trim(),
    modules: $('edit-modules').value.split(',').map(s => s.trim()).filter(Boolean),
    apis: $('edit-apis').value.trim(),
    notes: $('edit-notes').value.trim(),
    color: state.editColor,
    updatedAt: Date.now()
  };

  const saved = await HribletStorage.saveCapsule(capsule);
  const idx = state.capsules.findIndex(c => c.id === saved.id);
  if (idx >= 0) state.capsules[idx] = saved;
  else state.capsules.push(saved);

  state.activeCapsuleId = saved.id;
  state.activeProject = saved.project;
  await HribletStorage.set({ activeCapsuleId: saved.id, activeProject: saved.project });

  switchScreen('capsules');
  $$('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelector('[data-screen="capsules"]').classList.add('active');
  renderAll();
  showToast('✓ Capsule saved', 'success');
}

// ── Settings ─────────────────────────────────────────
function saveSettings() {
  state.settings = {
    autoDetect: $('set-autodetect').checked,
    showBadge: $('set-badge').checked,
    cloudSync: $('set-cloud').checked
  };
  HribletStorage.set({ settings: state.settings });
  showToast('Settings saved', 'info');
}

// ── Export / Import ───────────────────────────────────
function handleExport() {
  const data = JSON.stringify({ capsules: state.capsules, exportedAt: Date.now() }, null, 2);
  const blob = new Blob([data], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'hriblet-capsules.json';
  a.click();
  URL.revokeObjectURL(url);
  showToast('✓ Exported', 'success');
}

function handleImport(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = async (ev) => {
    try {
      const parsed = JSON.parse(ev.target.result);
      if (!parsed.capsules || !Array.isArray(parsed.capsules)) throw new Error('Invalid format');
      // Merge: skip duplicates by id
      const existingIds = new Set(state.capsules.map(c => c.id));
      const newCaps = parsed.capsules.filter(c => !existingIds.has(c.id));
      state.capsules = [...state.capsules, ...newCaps];
      await HribletStorage.set({ capsules: state.capsules });
      renderAll();
      showToast(`✓ Imported ${newCaps.length} capsule(s)`, 'success');
    } catch {
      showToast('Import failed — invalid JSON', 'error');
    }
  };
  reader.readAsText(file);
  e.target.value = '';
}

// ── Helpers ───────────────────────────────────────────
function getActiveCapsule() {
  return state.capsules.find(c => c.id === state.activeCapsuleId) || state.capsules[0] || null;
}

function platformName() {
  const names = { claude: 'Claude', chatgpt: 'ChatGPT', gemini: 'Gemini' };
  return names[state.platform] || 'AI';
}

function formatCapsuleText(cap) {
  return `[HRIBLET CONTEXT — ${cap.name}]
Project: ${cap.project}
Stack: ${(cap.stack || []).join(', ')}
Goal: ${cap.goal}
Modules: ${(cap.modules || []).join(', ')}
APIs: ${cap.apis}
Notes: ${cap.notes}
[END CONTEXT]`;
}

function esc(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

let toastTimer;
function showToast(msg, type = 'info') {
  const toast = $('toast');
  const icons = { success: '✓', error: '✕', info: '◆' };
  $('toast-icon').textContent = icons[type] || '';
  $('toast-msg').textContent = msg;
  toast.className = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.classList.remove('show'); }, 2500);
}

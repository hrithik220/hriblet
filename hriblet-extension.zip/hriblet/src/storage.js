// Hriblet Storage Utils
// Wraps chrome.storage.local with async helpers

const Storage = {
  async get(keys) {
    return new Promise((resolve) => chrome.storage.local.get(keys, resolve));
  },

  async set(data) {
    return new Promise((resolve) => chrome.storage.local.set(data, resolve));
  },

  async getCapsules() {
    const data = await this.get(['capsules']);
    return data.capsules || [];
  },

  async saveCapsule(capsule) {
    const capsules = await this.getCapsules();
    const idx = capsules.findIndex(c => c.id === capsule.id);
    const updated = { ...capsule, updatedAt: Date.now() };
    if (idx >= 0) capsules[idx] = updated;
    else capsules.push(updated);
    await this.set({ capsules });
    return updated;
  },

  async deleteCapsule(id) {
    const capsules = await this.getCapsules();
    await this.set({ capsules: capsules.filter(c => c.id !== id) });
  },

  async getSettings() {
    const data = await this.get(['settings']);
    return data.settings || { autoDetect: true, showBadge: true, cloudSync: false };
  },

  async getActiveState() {
    const data = await this.get(['activeProject', 'activeCapsuleId']);
    return data;
  },

  async setActiveState(project, capsuleId) {
    await this.set({ activeProject: project, activeCapsuleId: capsuleId });
  },

  generateId() {
    return 'cap_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  },

  timeAgo(ts) {
    const diff = Date.now() - ts;
    const m = Math.floor(diff / 60000);
    const h = Math.floor(diff / 3600000);
    const d = Math.floor(diff / 86400000);
    if (m < 1) return 'just now';
    if (m < 60) return `${m}m ago`;
    if (h < 24) return `${h}h ago`;
    return `${d}d ago`;
  }
};

window.HribletStorage = Storage;

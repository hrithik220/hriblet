// Hriblet Background Service Worker
// Handles cross-tab messaging and storage sync

chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // Seed with demo capsules on first install
    const demo = {
      capsules: [
        {
          id: 'cap_001',
          name: 'Campus Share v2',
          project: 'Campus Share',
          stack: ['React', 'Node.js', 'MongoDB', 'Socket.io'],
          goal: 'Real-time file sharing platform for university students with auth & role-based access.',
          modules: ['Auth', 'File Upload', 'Chat', 'Admin Panel'],
          apis: 'POST /upload · GET /files/:id · WS /room',
          notes: 'Currently fixing socket disconnect on mobile. JWT refresh token logic pending.',
          color: '#a29bfe',
          updatedAt: Date.now()
        },
        {
          id: 'cap_002',
          name: 'Thesis Research',
          project: 'Thesis',
          stack: ['Python', 'LaTeX', 'Jupyter'],
          goal: 'NLP-based thesis on Bengali text summarization using transformer models.',
          modules: ['Data Collection', 'Preprocessing', 'Model Training', 'Evaluation'],
          apis: 'HuggingFace API · Google Scholar',
          notes: 'Currently writing literature review — Chapter 3 on NLP benchmarks.',
          color: '#6ee7b7',
          updatedAt: Date.now() - 7200000
        },
        {
          id: 'cap_003',
          name: 'AI Startup MVP',
          project: 'Startup',
          stack: ['Next.js', 'Stripe', 'Supabase'],
          goal: 'B2B SaaS tool for AI-powered document workflows. Building landing + waitlist.',
          modules: ['Landing Page', 'Waitlist', 'Auth', 'Dashboard'],
          apis: 'Stripe Checkout · Supabase Auth · Resend Email',
          notes: 'B2B SaaS idea — landing page + waitlist flow. Need to add pricing page.',
          color: '#fbbf24',
          updatedAt: Date.now() - 86400000
        }
      ],
      activeProject: 'Campus Share',
      activeCapsuleId: 'cap_001',
      settings: {
        autoDetect: true,
        showBadge: true,
        cloudSync: false
      }
    };
    chrome.storage.local.set(demo);
  }
});

// Listen for messages from popup or content scripts
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'GET_PLATFORM') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]) {
        const url = tabs[0].url || '';
        let platform = 'unknown';
        if (url.includes('claude.ai')) platform = 'claude';
        else if (url.includes('chatgpt.com') || url.includes('chat.openai.com')) platform = 'chatgpt';
        else if (url.includes('gemini.google.com')) platform = 'gemini';
        sendResponse({ platform, url });
      }
    });
    return true;
  }

  if (message.type === 'INJECT_CAPSULE') {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs[0]?.id) {
        chrome.tabs.sendMessage(tabs[0].id, {
          type: 'DO_INJECT',
          capsule: message.capsule,
          platform: message.platform
        }, (response) => {
          sendResponse(response || { success: false, error: 'No response from content script' });
        });
      }
    });
    return true;
  }

  if (message.type === 'SAVE_CAPSULE') {
    chrome.storage.local.get(['capsules'], (data) => {
      const capsules = data.capsules || [];
      const idx = capsules.findIndex(c => c.id === message.capsule.id);
      if (idx >= 0) {
        capsules[idx] = { ...message.capsule, updatedAt: Date.now() };
      } else {
        capsules.push({ ...message.capsule, updatedAt: Date.now() });
      }
      chrome.storage.local.set({ capsules }, () => sendResponse({ success: true }));
    });
    return true;
  }

  if (message.type === 'DELETE_CAPSULE') {
    chrome.storage.local.get(['capsules'], (data) => {
      const capsules = (data.capsules || []).filter(c => c.id !== message.id);
      chrome.storage.local.set({ capsules }, () => sendResponse({ success: true }));
    });
    return true;
  }
});

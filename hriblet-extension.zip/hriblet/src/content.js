// Hriblet Content Script
// Detects AI platform and injects capsule context into the chat input

(function () {
  'use strict';

  const PLATFORMS = {
    claude: {
      name: 'Claude',
      selectors: [
        'div[contenteditable="true"].ProseMirror',
        'div[contenteditable="true"][data-placeholder]',
        'div.ProseMirror'
      ],
      inject: injectProseMirror
    },
    chatgpt: {
      name: 'ChatGPT',
      selectors: [
        '#prompt-textarea',
        'div[contenteditable="true"][data-id="root"]',
        'textarea[placeholder]'
      ],
      inject: injectTextarea
    },
    gemini: {
      name: 'Gemini',
      selectors: [
        'div.ql-editor[contenteditable="true"]',
        'rich-textarea div[contenteditable="true"]',
        'textarea[placeholder]'
      ],
      inject: injectProseMirror
    }
  };

  function detectPlatform() {
    const url = window.location.href;
    if (url.includes('claude.ai')) return 'claude';
    if (url.includes('chatgpt.com') || url.includes('chat.openai.com')) return 'chatgpt';
    if (url.includes('gemini.google.com')) return 'gemini';
    return null;
  }

  function findInput(platform) {
    const config = PLATFORMS[platform];
    if (!config) return null;
    for (const sel of config.selectors) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    return null;
  }

  function formatCapsule(capsule) {
    return `[HRIBLET CONTEXT — ${capsule.name}]
Project: ${capsule.project}
Stack: ${capsule.stack.join(', ')}
Goal: ${capsule.goal}
Modules: ${capsule.modules.join(', ')}
APIs: ${capsule.apis}
Notes: ${capsule.notes}
[END CONTEXT]

`;
  }

  function injectProseMirror(el, text) {
    el.focus();
    // Insert text at beginning
    const selection = window.getSelection();
    const range = document.createRange();
    range.selectNodeContents(el);
    range.collapse(true);
    selection.removeAllRanges();
    selection.addRange(range);

    document.execCommand('insertText', false, text);

    // Dispatch input events for React/Vue reactivity
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  function injectTextarea(el, text) {
    el.focus();
    const nativeSetter = Object.getOwnPropertyDescriptor(
      window.HTMLTextAreaElement.prototype, 'value'
    );
    if (nativeSetter && nativeSetter.set) {
      nativeSetter.set.call(el, text + (el.value || ''));
    } else {
      el.value = text + (el.value || '');
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    return true;
  }

  // Listen for inject commands from background
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'DO_INJECT') {
      const platform = detectPlatform();
      if (!platform) {
        sendResponse({ success: false, error: 'Platform not detected on this page' });
        return;
      }

      const config = PLATFORMS[platform];
      const input = findInput(platform);

      if (!input) {
        sendResponse({ success: false, error: `Could not find chat input on ${config.name}` });
        return;
      }

      const text = formatCapsule(message.capsule);

      try {
        const result = config.inject(input, text);
        sendResponse({ success: result });
      } catch (e) {
        sendResponse({ success: false, error: e.message });
      }
    }
  });

  // Show a subtle Hriblet badge on detected AI pages
  function showHribletBadge() {
    if (document.getElementById('hriblet-badge')) return;
    const badge = document.createElement('div');
    badge.id = 'hriblet-badge';
    badge.innerHTML = `
      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <path d="M9.5 2A2.5 2.5 0 0 1 12 4.5v15a2.5 2.5 0 0 1-4.96-.46 2.5 2.5 0 0 1-2.96-3.08 3 3 0 0 1-.34-5.58 2.5 2.5 0 0 1 1.32-4.24 2.5 2.5 0 0 1 1.98-3Z"/>
        <path d="M14.5 2A2.5 2.5 0 0 0 12 4.5v15a2.5 2.5 0 0 0 4.96-.46 2.5 2.5 0 0 0 2.96-3.08 3 3 0 0 0 .34-5.58 2.5 2.5 0 0 0-1.32-4.24 2.5 2.5 0 0 0-1.98-3Z"/>
      </svg>
      Hriblet active
    `;
    badge.style.cssText = `
      position: fixed;
      bottom: 16px;
      right: 16px;
      background: #1a1a2e;
      color: #a29bfe;
      border: 1px solid #2d2560;
      border-radius: 20px;
      padding: 5px 10px;
      font-size: 11px;
      font-family: system-ui, sans-serif;
      display: flex;
      align-items: center;
      gap: 5px;
      z-index: 99999;
      cursor: pointer;
      opacity: 0.85;
      transition: opacity 0.2s;
    `;
    badge.title = 'Hriblet — click to open';
    badge.onclick = () => badge.style.opacity = '0';
    document.body.appendChild(badge);
    setTimeout(() => { badge.style.opacity = '0'; }, 4000);
  }

  if (detectPlatform()) {
    showHribletBadge();
  }
})();
